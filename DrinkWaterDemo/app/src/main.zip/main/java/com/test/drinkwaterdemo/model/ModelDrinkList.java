package com.test.drinkwaterdemo.model;

/**
 * Created by Avinash Kahal on 28-Jun-17.
 */

public class ModelDrinkList {

    String id;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    String drink_list_weight;
    String drink_list_time;
    String drink_list_date;
    String drink_list_img;
    String drink_list_quantityml;
    String drink_list_total_quantityml;

    public String getDrink_list_weight() {
        return drink_list_weight;
    }

    public void setDrink_list_weight(String drink_list_weight) {
        this.drink_list_weight = drink_list_weight;
    }

    public String getDrink_list_time() {
        return drink_list_time;
    }

    public void setDrink_list_time(String drink_list_time) {
        this.drink_list_time = drink_list_time;
    }

    public String getDrink_list_date() {
        return drink_list_date;
    }

    public void setDrink_list_date(String drink_list_date) {
        this.drink_list_date = drink_list_date;
    }

    public String getDrink_list_img() {
        return drink_list_img;
    }

    public void setDrink_list_img(String drink_list_img) {
        this.drink_list_img = drink_list_img;
    }

    public String getDrink_list_quantityml() {
        return drink_list_quantityml;
    }

    public void setDrink_list_quantityml(String drink_list_quantityml) {
        this.drink_list_quantityml = drink_list_quantityml;
    }

    public String getDrink_list_total_quantityml() {
        return drink_list_total_quantityml;
    }

    public void setDrink_list_total_quantityml(String drink_list_total_quantityml) {
        this.drink_list_total_quantityml = drink_list_total_quantityml;
    }
}
