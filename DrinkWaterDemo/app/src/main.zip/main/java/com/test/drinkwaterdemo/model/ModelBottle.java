package com.test.drinkwaterdemo.model;

/**
 * Created by Avinash Kahal on 28-Jun-17.
 */

public class ModelBottle {

    String bottle_type;

    public String getBottle_type() {
        return bottle_type;
    }

    public void setBottle_type(String bottle_type) {
        this.bottle_type = bottle_type;
    }
}
